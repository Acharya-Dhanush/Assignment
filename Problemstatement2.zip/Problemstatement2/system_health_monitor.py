import psutil
import logging
import time

# Set up logging
logging.basicConfig(filename='system_health.log', level=logging.INFO, format='%(asctime)s - %(message)s')

# Define thresholds
CPU_THRESHOLD = 80  # CPU usage threshold in percentage
MEMORY_THRESHOLD = 80  # Memory usage threshold in percentage
DISK_THRESHOLD = 90  # Disk usage threshold in percentage

# Function to check CPU usage
def check_cpu_usage():
    cpu_usage = psutil.cpu_percent(interval=1)
    if cpu_usage > CPU_THRESHOLD:
        logging.warning(f"High CPU usage detected: {cpu_usage}%")
    else:
        logging.info(f"CPU usage: {cpu_usage}%")

# Function to check memory usage
def check_memory_usage():
    memory = psutil.virtual_memory()
    if memory.percent > MEMORY_THRESHOLD:
        logging.warning(f"High Memory usage detected: {memory.percent}%")
    else:
        logging.info(f"Memory usage: {memory.percent}%")

# Function to check disk space usage
def check_disk_usage():
    disk = psutil.disk_usage('/')
    if disk.percent > DISK_THRESHOLD:
        logging.warning(f"High Disk usage detected: {disk.percent}%")
    else:
        logging.info(f"Disk usage: {disk.percent}%")

# Function to check running processes
def check_running_processes():
    processes = [proc.info for proc in psutil.process_iter(['pid', 'name'])]  # List running processes
    logging.info(f"Running processes: {len(processes)} processes")

# Main function to monitor system health
def monitor_system_health():
    check_cpu_usage()
    check_memory_usage()
    check_disk_usage()
    check_running_processes()

# Run the monitor every minute
if __name__ == '__main__':
    while True:
        monitor_system_health()
        time.sleep(60)  # Sleep for 60 seconds before checking again
