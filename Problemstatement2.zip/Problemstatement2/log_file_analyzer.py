import re
from collections import Counter

# Define the log file path (e.g., Apache or Nginx log file)
LOG_FILE_PATH = '/var/log/apache2/access.log'  # Change path as needed

# Function to analyze the log file
def analyze_log_file(log_file_path):
    # Regular expression pattern to match log lines
    log_pattern = r'(?P<ip_address>\d+\.\d+\.\d+\.\d+) - - \[.*\] ".*" \d+ \d+ "(?P<requested_page>.*)"'

    ip_counter = Counter()
    page_counter = Counter()
    error_404_count = 0

    with open(log_file_path, 'r') as log_file:
        for line in log_file:
            match = re.match(log_pattern, line)
            if match:
                ip_address = match.group('ip_address')
                requested_page = match.group('requested_page')

                # Count IP addresses and pages
                ip_counter[ip_address] += 1
                page_counter[requested_page] += 1

                # Count 404 errors
                if '404' in line:
                    error_404_count += 1

    # Output the results
    print(f"Total 404 Errors: {error_404_count}")
    print("Most Requested Pages:")
    for page, count in page_counter.most_common(5):
        print(f"{page}: {count} times")
    
    print("IP Addresses with Most Requests:")
    for ip, count in ip_counter.most_common(5):
        print(f"{ip}: {count} requests")

# Run the log file analysis
if __name__ == '__main__':
    analyze_log_file(LOG_FILE_PATH)
