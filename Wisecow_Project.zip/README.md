# Wisecow Application Deployment

This project demonstrates the containerization and deployment of the Wisecow application on Kubernetes with CI/CD and TLS support.

## Steps

1. **Build Docker Image**
   ```bash
   docker build -t wisecow-app:latest .
   ```

2. **Run Locally**
   ```bash
   docker run -p 8000:8000 wisecow-app:latest
   ```

3. **Kubernetes Deployment**
   - Apply the Kubernetes manifests in the `k8s/` folder.

4. **CI/CD Pipeline**
   - GitHub Actions workflow automates build and deployment.

5. **TLS**
   - Secure the application with HTTPS using the provided ingress file.

---